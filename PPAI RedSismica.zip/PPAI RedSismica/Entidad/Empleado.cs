﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPAI_RedSismica.Entidad
{
    internal class Empleado
    {
        private string mail;

        public string Mail
        { 
            get { return mail; } 
            set { mail = value; } 
        }
    }
}
