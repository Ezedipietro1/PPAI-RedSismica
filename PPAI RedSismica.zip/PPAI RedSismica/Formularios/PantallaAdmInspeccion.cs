namespace PPAI_RedS�smica
{
    public partial class PantallaAdmInspeccion : Form
    {
        public PantallaAdmInspeccion()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
